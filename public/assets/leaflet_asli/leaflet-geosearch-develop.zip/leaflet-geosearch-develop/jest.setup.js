require('jest-fetch-mock').enableMocks();
require('dotenv').config({ path: '.env' });
global.L = require('leaflet');
